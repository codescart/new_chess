const String HomeRoute = 'home';
const String AboutRoute = 'about';
const String EpisodesRoute = 'episodes';
const String EpisodeDetailsRoute = 'episode';
