# flutter chess
A flutter chess application with integrated bot, local game as well as online-multiplayer support.

<hr style="border:2px solid gray">

<a href='https://play.google.com/store/apps/details?id=com.lurzapps.chess&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' height="76"/></a><img src="https://chess-45a81.web.app/favicon.png" width="76" height="76" alt="website" title="website" /></a>
